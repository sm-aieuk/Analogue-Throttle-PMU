# Git-Smart Upload Script
$port = "COM3"
$projectRoot = "$PSScriptRoot"
$targetRoot = "/sd"

Write-Host "=== PMU Git-Smart Upload (full) ===" -ForegroundColor Cyan

Write-Host "Stopping MicroPython..." -ForegroundColor Yellow
mpremote connect $port stop
Start-Sleep -Milliseconds 500

$changed = git status --porcelain | Where-Object { $_ -match "^\s*[MA?]" }

if ($changed.Count -eq 0) {
    Write-Host "No modified/added/untracked files. Nothing to upload." -ForegroundColor Yellow
} else {
    foreach ($entry in $changed) {
        $relative = $entry.Substring(3)
        if ($relative -notmatch "\.py$") { continue }

        $local = Join-Path $projectRoot $relative
        if (!(Test-Path $local)) { continue }

        $remote = "$targetRoot/$relative"

        Write-Host "→ Uploading $relative" -ForegroundColor Green

        $remoteDir = Split-Path $remote
        mpremote connect $port fs mkdir $remoteDir 2>$null
        mpremote connect $port fs put $local $remote
    }
}

Write-Host "Upload complete." -ForegroundColor Cyan

mpremote connect $port reset
Start-Sleep -Seconds 2
mpremote connect $port run "$targetRoot/main.py"
mpremote connect $port repl
