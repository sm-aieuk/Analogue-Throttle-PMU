# Full Upload Script
$port = "COM3"
$projectRoot = "$PSScriptRoot"
$targetRoot = "/sd"

Write-Host "=== PMU Full Upload (ALL FILES) ===" -ForegroundColor Cyan

Write-Host "Stopping MicroPython..." -ForegroundColor Yellow
mpremote connect $port stop
Start-Sleep -Milliseconds 500

$files = Get-ChildItem -Recurse -Filter *.py

foreach ($file in $files) {
    $relative = $file.FullName.Replace("$projectRoot\", "")
    $remote = "$targetRoot/$relative"

    Write-Host "→ Uploading $relative" -ForegroundColor Green

    $remoteDir = Split-Path $remote
    mpremote connect $port fs mkdir $remoteDir 2>$null
    mpremote connect $port fs put $file.FullName $remote
}

Write-Host "Full upload complete." -ForegroundColor Cyan

mpremote connect $port reset
Start-Sleep -Seconds 2
mpremote connect $port run "$targetRoot/main.py"
mpremote connect $port repl
